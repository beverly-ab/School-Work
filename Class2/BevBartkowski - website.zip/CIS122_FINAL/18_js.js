        function whichType() {

            if (window.document.superPet.radioBtn[0].checked == true) {
                window.document.superPet.theType.value = "A fire breathing dragon!";
            }
            if (window.document.superPet.radioBtn[1].checked == true) {
                window.document.superPet.theType.value = "An elegant unicorn!";
            }
            if (window.document.superPet.radioBtn[2].checked == true) {
                window.document.superPet.theType.value = "A powerful pegasus!";
            }
        }
